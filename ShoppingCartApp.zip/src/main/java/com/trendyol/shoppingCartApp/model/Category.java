package com.trendyol.shoppingCartApp.model;

public class Category {

	private String categoryTitle ;
	
	public Category(String title) {
		this.categoryTitle = title;
	}
	

	public String getTitle() {
		return categoryTitle;
	}

	public void setTitle(String title) {
		this.categoryTitle = title;
	}
	
	
	
	
	
}
