package com.trendyol.shoppingCartApp;

import org.junit.Test;


public class ShoppingCartAppApplicationTests {

	@Test
	public void contextLoads() {
	}

}
