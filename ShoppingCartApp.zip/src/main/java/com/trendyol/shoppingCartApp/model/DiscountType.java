package com.trendyol.shoppingCartApp.model;

public enum DiscountType {
	Rate, 
	Amount ;
}
